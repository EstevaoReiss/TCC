// Declaramos todo os botões do container de acessibilidade
const aumentarFont = document.querySelector("#aumentar");
const diminuirFont = document.querySelector("#diminuir");
const reset = document.querySelector("#reset");
const doc = document.querySelector("html")
const fonteStorage = localStorage.getItem("fonte")

// Aqui verificamos as variaveis do localstorage que são setadas pelos botões, pra continuar as definições pras outras paginas. Caso tenham, serão colocadas as classes no document que fará a estilização

if (fonteStorage == "aumentada") {
    doc.classList.add("aumentada")
}

if (fonteStorage == "diminuida") {
    doc.classList.add("diminuida")
}

// botao para aumentar a fonte

aumentarFont.addEventListener("click", () => {
    if (doc.classList.contains("diminuida")) {
        doc.classList.remove("diminuida")
        localStorage.setItem("fonte", "normal")

    } else {
        doc.classList.add("aumentada")
        localStorage.setItem("fonte", "aumentada")

    }
})

// botao para diminuir a fonte
diminuirFont.addEventListener("click", () => {
    if (doc.classList.contains("aumentada")) {
        doc.classList.remove("aumentada")
        localStorage.setItem("fonte", "normal")

    } else {
        doc.classList.add("diminuida")
        localStorage.setItem("fonte", "diminuida")

    }
})


// retirar todas as config de acessibilidade
reset.addEventListener("click", () => {
    doc.classList.remove("diminuida")
    doc.classList.remove("aumentada")
    localStorage.setItem("fonte", "normal")
})


