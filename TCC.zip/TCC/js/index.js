let contador = 1;

setInterval(function(){
    
    document.getElementById('img' + contador).checked = true;
    contador++;

    if(contador > 5) {
        contador = 1;
    }

}, 7000);

setInterval(function(){
    
    document.getElementById('barra' + contador).checked = true;
    contador++;

    if(contador > 5) {
        contador = 1;
    }

}, 7000);